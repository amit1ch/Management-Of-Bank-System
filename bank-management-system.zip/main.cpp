#include<stdio.h>
#include<iostream>
#include<conio.h> 
using namespace std;
class bank{
      char name[100],add[100],y;
     float balance;
      
      public:
       void open_account();
       void deposite_money();
       void withdraw_money();
       void display_account();
       
};
void bank :: open_account(){
      cout<<"Enter your full name :: ";
      cin.ignore();
      cin.getline(name,100);
      cout<<"Enter your address :: ";
      cin.ignore();
      cin.getline(add,100);
      cout<<"What type of account you want to open Savine(s) or Current (c) ";
      cin>>y;
      cout<<"Enter amount for deposite :: ";
      cin>>balance;
      cout<<"Your account is created \n";
}
void bank :: deposite_money(){
     float a;
      cout<<"Enter how much You want to deposite :: ";
      cin>>a;
      balance=balance+a;
      cout<<"Total amount you deposit :: "<<balance<<"\n";
}
void bank :: display_account(){
      cout<<"\nYour full name :: "<<name;
      cout<<"\nYour address :: "<<add;
      cout<<"\nType of account that you open :: "<< y;
      cout<<"\nAmount you deposite :: "<<balance;
}
void bank :: withdraw_money(){
      float amount ;
      cout<<"\nWithdraw :: ";
      cout<<"Enter amount you want to withdraw :: ";
      cin>>amount;
      balance=balance - amount;
      cout<<"Total amount is left :: "<< balance;
}
int main(){
      int ch;
      char x;
      bank obj;
  do{
   cout<<"1) Open account \n";
   cout<<"2) Deposite money \n";
   cout<<"3) Withdraw money \n";
   cout<<"4) Display account \n";
   cout<<"5) Exit \n";
   cout<<"Select the option from above \n ";
   cin>>ch;
   switch(ch){
      case 1 :
         cout<<"1) Open account \n";
         obj.open_account();
         break;
      case 2 :
         cout<<"2) Deposite money \n";
         obj.deposite_money();
         break;
      case 3:
         cout<<"3) Withdraw money: \n";
         obj.withdraw_money();
         break;
      case 4:
         cout<<"4) Display money:\n";
         obj.display_account();
         break;
         case 5:
            if(ch==5){
            exit(1); 
            }
      default :
          cout<<"This is not exist try again \n ";
       }
        
     cout<<"\nDo you want to select next option then press :: y \n";
     cout<<"If you want to exit then press :: N \n";
     cin>>x;
     if(x=='n'||x=='N')
       exit(0);
       }
       while(x=='y'||x=='Y');
        getch();
         
          return 0;
      }
